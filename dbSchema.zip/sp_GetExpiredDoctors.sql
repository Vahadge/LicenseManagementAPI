USE [LicenseManagementDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetExpiredDoctors]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE [dbo].[sp_GetExpiredDoctors]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Id,
        FullName,
        Email,
        Specialization,
        LicenseNumber,
        LicenseExpiryDate,
        [Status],
        CreatedDate,
        ModifiedDate
    FROM  dbo.Doctors
    WHERE IsDeleted = 0
      AND [Status]  = 'Expired'
    ORDER BY LicenseExpiryDate ASC;
END

GO


