USE [LicenseManagementDB]
GO

/****** Object:  Table [dbo].[Doctors]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Doctors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FullName] [nvarchar](200) NOT NULL,
	[Email] [nvarchar](255) NOT NULL,
	[Specialization] [nvarchar](200) NOT NULL,
	[LicenseNumber] [nvarchar](100) NOT NULL,
	[LicenseExpiryDate] [date] NOT NULL,
	[Status] [nvarchar](20) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[ModifiedDate] [datetime] NULL,
 CONSTRAINT [PK_Doctors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UQ_Doctors_Email] UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [UQ_Doctors_LicenseNumber] UNIQUE NONCLUSTERED 
(
	[LicenseNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Doctors] ADD  CONSTRAINT [DF_Doctors_Status]  DEFAULT ('Active') FOR [Status]
GO

ALTER TABLE [dbo].[Doctors] ADD  CONSTRAINT [DF_Doctors_CreatedDate]  DEFAULT (getutcdate()) FOR [CreatedDate]
GO

ALTER TABLE [dbo].[Doctors] ADD  CONSTRAINT [DF_Doctors_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
GO

ALTER TABLE [dbo].[Doctors]  WITH CHECK ADD  CONSTRAINT [CHK_Doctors_Status] CHECK  (([Status]='Suspended' OR [Status]='Expired' OR [Status]='Active'))
GO

ALTER TABLE [dbo].[Doctors] CHECK CONSTRAINT [CHK_Doctors_Status]
GO


