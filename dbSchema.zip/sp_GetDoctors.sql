USE [LicenseManagementDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetDoctors]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE [dbo].[sp_GetDoctors]
    @Search     NVARCHAR(200) = NULL,
    @Status     NVARCHAR(20)  = NULL,
    @PageNumber INT           = 1,
    @PageSize   INT           = 10
AS
BEGIN
    SET NOCOUNT ON;

    -- Clamp to valid range
    SET @PageSize   = CASE WHEN @PageSize   < 1   THEN 10  WHEN @PageSize > 100 THEN 100 ELSE @PageSize   END;
    SET @PageNumber = CASE WHEN @PageNumber < 1   THEN 1                                  ELSE @PageNumber END;

    -- Paged result set
    SELECT
        Id,
        FullName,
        Email,
        Specialization,
        LicenseNumber,
        LicenseExpiryDate,
        [Status],
        CreatedDate,
        ModifiedDate
    FROM  dbo.Doctors
    WHERE IsDeleted = 0
      AND (@Search IS NULL
           OR FullName      LIKE '%' + @Search + '%'
           OR LicenseNumber LIKE '%' + @Search + '%')
      AND (@Status IS NULL OR [Status] = @Status)
    ORDER BY CreatedDate DESC
    OFFSET  (@PageNumber - 1) * @PageSize ROWS
    FETCH NEXT @PageSize ROWS ONLY;

    -- Total count for pagination (same filters, no ORDER BY / OFFSET)
    SELECT COUNT(*) AS TotalCount
    FROM  dbo.Doctors
    WHERE IsDeleted = 0
      AND (@Search IS NULL
           OR FullName      LIKE '%' + @Search + '%'
           OR LicenseNumber LIKE '%' + @Search + '%')
      AND (@Status IS NULL OR [Status] = @Status);
END

GO


