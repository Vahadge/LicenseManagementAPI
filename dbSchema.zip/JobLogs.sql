USE [LicenseManagementDB]
GO

/****** Object:  Table [dbo].[JobLog]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[JobLog](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[JobName] [nvarchar](100) NOT NULL,
	[StartedAt] [datetime] NOT NULL,
	[CompletedAt] [datetime] NULL,
	[RecordsAffected] [int] NULL,
	[Status] [nvarchar](20) NOT NULL,
	[ErrorMessage] [nvarchar](max) NULL,
 CONSTRAINT [PK_JobLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[JobLog] ADD  CONSTRAINT [DF_JobLog_StartedAt]  DEFAULT (getutcdate()) FOR [StartedAt]
GO

ALTER TABLE [dbo].[JobLog] ADD  CONSTRAINT [DF_JobLog_Status]  DEFAULT ('Running') FOR [Status]
GO

ALTER TABLE [dbo].[JobLog]  WITH CHECK ADD  CONSTRAINT [CHK_JobLog_Status] CHECK  (([Status]='Failed' OR [Status]='Completed' OR [Status]='Running'))
GO

ALTER TABLE [dbo].[JobLog] CHECK CONSTRAINT [CHK_JobLog_Status]
GO


